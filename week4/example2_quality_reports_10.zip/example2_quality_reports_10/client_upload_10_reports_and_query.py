# client_upload_10_reports_and_query.py
# 예제2 서버에 품질 리포트 10개를 모두 업로드하고 top_k=3 검색 결과를 확인합니다.
#
# 먼저 실행:
# python example2_document_qa/server_document_qa.py
#
# 그 다음 실행:
# python client_upload_10_reports_and_query.py

import asyncio
import json
from pathlib import Path
from typing import Any
from fastmcp import Client

SERVER_URL = "http://127.0.0.1:8002/mcp"
REPORT_DIR = Path("sample_quality_reports_10")

def print_box(title: str, data: Any):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)
    if isinstance(data, (dict, list)):
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(data)

async def main():
    report_files = sorted(REPORT_DIR.glob("*.txt"))
    client = Client(SERVER_URL)

    async with client:
        tools = await client.list_tools()
        print_box("MCP Tool 목록", [tool.name for tool in tools])

        for file_path in report_files:
            result = await client.call_tool("upload_document", {"file_path": str(file_path)})
            print_box(f"업로드: {file_path.name}", result.data)

        questions = [
            "냉매 누설의 원인과 개선 조치는 무엇인가요?",
            "팬 모터 소음 문제는 어떤 제품에서 발생했고 원인은 무엇인가요?",
            "건조 부족 문제의 원인과 개선 방향은 무엇인가요?",
            "배터리 충전 불량의 원인 후보는 무엇인가요?",
            "카메라 초점 불량 문제의 개선 조치는 무엇인가요?",
        ]

        for q in questions:
            result = await client.call_tool("ask_question", {"query": q, "top_k": 3})
            print_box(f"질문 top_k=3: {q}", result.data)

if __name__ == "__main__":
    asyncio.run(main())
