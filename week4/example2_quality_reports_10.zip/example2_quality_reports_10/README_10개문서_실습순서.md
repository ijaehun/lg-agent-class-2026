# 예제2 문서 Q&A용 품질 리포트 10개 데이터

기존 `sample_quality_report.txt` 형식을 참고해 만든 품질 리포트 10개입니다.

## 사용 방법

이 ZIP을 풀고 아래 두 항목을 기존 `mcp_class_all_examples` 폴더 안에 복사하세요.

```text
sample_quality_reports_10/
client_upload_10_reports_and_query.py
```

권장 구조:

```text
mcp_class_all_examples/
├─ example2_document_qa/
│  ├─ server_document_qa.py
│  └─ client_document_qa.py
├─ sample_quality_reports_10/
│  ├─ quality_report_01_wall_ac_refrigerant_leak.txt
│  └─ ...
└─ client_upload_10_reports_and_query.py
```

## 실행 순서

터미널 1:

```bash
python example2_document_qa/server_document_qa.py
```

터미널 2:

```bash
python client_upload_10_reports_and_query.py
```

## 설명 포인트

`top_k=3`은 질문과 가장 유사한 문서 조각 3개를 가져오라는 의미입니다.
문서가 1개뿐이면 검색 후보가 적지만, 문서가 10개 있으면 질문과 관련된 문서가 상위 검색 결과로 선택되는 과정을 보여주기 좋습니다.

흐름:

```text
질문 입력
→ 질문 embedding 생성
→ ChromaDB에서 유사한 chunk 검색
→ top_k=3개 context 선택
→ 답변 생성
```
